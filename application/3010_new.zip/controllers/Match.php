<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Match extends CI_Controller {

    public function index(){
        $data = array(
            'title' => "Beranda", 
        );
        $this->load->view('beranda', $data);
    }

// ================================== CLEAR DATA ==========================================
    public function trash(){

        $data = array(
            'title'  => "Orchard Appointment", 
        );
        $this->load->view('bersih/form', $data);
    }

    public function trash2(){

        $tgl1 = $this->input->post('tgl1');
        $tgl2 = $this->input->post('tgl2');

        $app    = "Delete from tb_appoiment WHERE tgl BETWEEN '$tgl1' AND '$tgl2'";
        $res1   = $this->db->query($app);

        $denda  = "Delete from ctt_denda WHERE tanggal BETWEEN '$tgl1' AND '$tgl2'";
        $res2   = $this->db->query($denda);

        $kasbon = "Delete from ctt_kasbon WHERE tanggal BETWEEN '$tgl1' AND '$tgl2'";
        $res3   = $this->db->query($kasbon);

        $tips   = "Delete from ctt_tips WHERE tanggal BETWEEN '$tgl1' AND '$tgl2'";
        $res4   = $this->db->query($tips);

        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">*Data Appoitment <br>*Data Denda <br>*Data Kasbon <br>*Data Tips <br> Berhasil Di Hapus !! <div class="ml-5 btn btn-sm"><i class="fas fa-trash fa-2x"></i></div></div>');
        redirect("Match/trash");

    }
// ================================== END CLEAR DATA ==========================================

// ================================== APPOITMENT ==========================================

    public function appoiment(){
        if (!empty($this->session->userdata('tgl1'))) {
            $dt_a   = $this->session->userdata('tgl1');
            $dt_b   = $this->session->userdata('tgl2');
            $data = array(
                'title'  => "Orchard Appointment", 
                'anak'   => $this->M_salon->ambil_anak(),
                'app'    => $this->M_salon->dt_app(" where tgl BETWEEN '$dt_a' AND '$dt_b' "),
            );
        }else{
            $dt   = date('Y-m-d');
            $data = array(
                'title'  => "Orchard Appointment", 
                'anak'   => $this->M_salon->ambil_anak(),
                'app'    => $this->M_salon->dt_app(" where tgl_input = '$dt' "),
            );
        }
        $this->load->view('appoiment/tabel', $data);
    }

    public function appoiment2(){
        $dt_a = $this->input->post('tgl1');
        $dt_b = $this->input->post('tgl2');
        $sesi = array(
            'tgl1' => $this->input->post('tgl1'), 
            'tgl2' => $this->input->post('tgl2'), 
        );
        $this->session->set_userdata($sesi);
        $data = array(
            'title'  => "Orchard Appointment", 
            'anak'   => $this->M_salon->ambil_anak(),
            'app'    => $this->M_salon->dt_app(" where tgl BETWEEN '$dt_a' AND '$dt_b' "),
        );
        $this->load->view('appoiment/tabel', $data);
    }

    function input_app(){
        $tgl    = $this->input->post('tanggal'); 
        $kd_app = $this->input->post('kd_app'); 
        $cek = $this->db->get_where(" tb_appoiment where kd_app = '$kd_app' and tgl = '$tgl' ")->row();
        if ($cek) {
            echo "Nomor <b style='color: red;'>".$kd_app."</b> Sudah digunakan ... Kembali" ; exit;
        }else{

            $data_input = array(
                'tgl'       => $this->input->post('tanggal'),
                // 'kd_app'    => $this->input->post('kd_app'),
                // 'jam'       => $this->input->post('jam'),
                // 'ket'       => strtoupper($this->input->post('ket')),
                'id_kry_2'  => $this->input->post('id_kry_2'),
                'nm_app'    => strtoupper($this->input->post('nm_app')),
                'org'       => $this->input->post('org'),
                'nominal'   => ($this->input->post('org') * 5000),
                'admin'     => $this->session->userdata('nm_user'),
                'tgl_input' => date('Y-m-d')
            );
            $res  = $this->M_salon->InputData('tb_appoiment', $data_input);
            $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Input !! <div class="ml-5 btn btn-sm"><i class="fas fa-cloud-download-alt fa-2x"></i></div></div>');
            redirect("Match/appoiment");
        }
    }

    public function edit_app($id_app){
        $a = $this->M_salon->dt_app(" where id_app ='$id_app' ");
        $data = array(
            "id_app"     => $a[0]->id_app,
            "kd_app"     => $a[0]->kd_app,
            "jam"        => $a[0]->jam,
            "id_kry_2"   => $a[0]->id_kry_2,
            "nm_app"     => $a[0]->nm_app,
            "tgl"        => $a[0]->tgl,
            "ket"        => $a[0]->ket,
            "org"        => $a[0]->org,
            "nominal"    => $a[0]->nominal,
            'title'      => "Edit Appointment", 
            'anak'       => $this->M_salon->ambil_anak()
        );
        $this->load->view('appoiment/form_edit', $data);
    }

    function update_app(){
        $id_app  = $this->input->post('id_app');
        $data_input = array(
            // 'kd_app'    => $this->input->post('kd_app'),
            // 'jam'       => $this->input->post('jam'),
            'tgl'       => $this->input->post('tgl'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_app'    => strtoupper($this->input->post('nm_app')),
            'org'       => $this->input->post('org'),
            'nominal'   => ($this->input->post('org') * 5000),
        );
        $where = array('id_app' => $id_app);
        $res  = $this->M_salon->UpdateData('tb_appoiment', $data_input, $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Update !!  <div class="ml-5 btn btn-sm"><i class="fas fa-sync-alt fa-2x"></i></div></div>');
        redirect("Match/appoiment");
    }

    function drop_app($id_app){
        $where = array('id_app' => $id_app);
        $res = $this->M_salon->DropData('tb_appoiment', $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Hapus !!  <div class="ml-5 btn btn-sm"><i class="fas fa-times-circle fa-2x"></i></div></div>');
        redirect("Match/appoiment");
    }

    public function rekap_app(){
        $dt   = date('Y-m-d');
        $dt_a = date('Y-m-25');
        $dt_b = date('Y-m-26');
        $dt_c = date('Y-m-d', strtotime($dt_a.'-1 month'));
        $data = array(
            'title'  => "Orchard Appointment", 
            'salon'  => $this->M_salon->dt_kry(),
        );
        $this->load->view('appoiment/rekap', $data);
    }

    function summary_app(){
        $tgl1 = $this->input->post('tgl1');
        $tgl2 = $this->input->post('tgl2');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'app'       => $this->M_salon->summary_app($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        ); 

        $this->load->view('appoiment/summary_export', $data);
    }

    function excel_app_sum(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'app'       => $this->M_salon->summary_app($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2)),
        ); 

        $this->load->view('appoiment/excel_sum', $data);
    }

    function excel_app_det(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'app'       => $this->M_salon->dt_app(" where tgl BETWEEN '$tgl1' AND '$tgl2' "),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2)),
        ); 

        $this->load->view('appoiment/excel_det', $data);
    }

// ================================== END APPOIMENT ==========================================

// ================================== DENDA ==========================================

    public function denda(){
        if (!empty($this->session->userdata('tgl1'))) {
            $dt_a   = $this->session->userdata('tgl1');
            $dt_b   = $this->session->userdata('tgl2');
            $data = array(
                'title'  => "Orchard Beauty", 
                'anak'   => $this->M_salon->ambil_anak(),
                'denda'  => $this->M_salon->dt_denda(" where tanggal BETWEEN '$dt_a' AND '$dt_b' "),
            );
        }else{
            $dt   = date('Y-m-d');
            $data = array(
                'title'  => "Orchard Beauty", 
                'anak'   => $this->M_salon->ambil_anak(),
                'denda'  => $this->M_salon->dt_denda(" where tgl_input = '$dt' "),
            );
        }

        $this->load->view('denda/tabel', $data);
    }

    public function denda2(){
        $dt_a = $this->input->post('tgl1');
        $dt_b = $this->input->post('tgl2');
        $sesi = array(
            'tgl1' => $this->input->post('tgl1'), 
            'tgl2' => $this->input->post('tgl2'), 
        );
        $this->session->set_userdata($sesi);
        $data = array(
            'title'  => "Orchard Beauty", 
            'anak'   => $this->M_salon->ambil_anak(),
            'denda'  => $this->M_salon->dt_denda(" where tanggal BETWEEN '$dt_a' AND '$dt_b' "),
        );
        $this->load->view('denda/tabel', $data);
    }

    function input_denda(){
        $data_input = array(
            'tanggal'   => $this->input->post('tanggal'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_denda'  => strtoupper($this->input->post('nm_denda')),
            'alasan'    => $this->input->post('alasan'),
            'nominal'   => $this->input->post('nominal'),
            'admin'     => $this->session->userdata('nm_user'),
            'tgl_input' => date('Y-m-d')
        );
        $res  = $this->M_salon->InputData('ctt_denda', $data_input);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Input !! <div class="ml-5 btn btn-sm"><i class="fas fa-cloud-download-alt fa-2x"></i></div></div>');
        redirect("Match/denda");
    }

    public function edit_denda($id_denda){
        $a = $this->M_salon->dt_denda(" where id_denda ='$id_denda' ");
        $data = array(
            "id_denda"   => $a[0]->id_denda,
            "id_kry_2"   => $a[0]->id_kry_2,
            "nm_denda"   => $a[0]->nm_denda,
            "tanggal"     => $a[0]->tanggal,
            "alasan"     => $a[0]->alasan,
            "nominal"    => $a[0]->nominal,
            'title'      => "Edit Denda", 
            'anak'       => $this->M_salon->ambil_anak()
        );
        $this->load->view('denda/form_edit', $data);
    }

    function update_denda(){
        $id_denda  = $this->input->post('id_denda');
        $data_input = array(
            'tanggal'   => $this->input->post('tanggal'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_denda'  => strtoupper($this->input->post('nm_denda')),
            'alasan'    => $this->input->post('alasan'),
            'nominal'   => $this->input->post('nominal')
        );
        $where = array('id_denda' => $id_denda);
        $res  = $this->M_salon->UpdateData('ctt_denda', $data_input, $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Update !!  <div class="ml-5 btn btn-sm"><i class="fas fa-sync-alt fa-2x"></i></div></div>');
        redirect("Match/denda");
    }

    function drop_denda($id_denda){
        $where = array('id_denda' => $id_denda);
        $res = $this->M_salon->DropData('ctt_denda', $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Hapus !!  <div class="ml-5 btn btn-sm"><i class="fas fa-times-circle fa-2x"></i></div></div>');
        redirect("Match/denda");
    }

    function summary_denda(){
        $tgl1 = $this->input->post('tgl3');
        $tgl2 = $this->input->post('tgl4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'denda'     => $this->M_salon->summary_denda($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('denda/summary_export', $data);
    }

    function excel_denda_sum(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'denda'     => $this->M_salon->summary_denda($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('denda/excel_sum', $data);
    }


// =============================== DENDA ==========================================

// ================================== KASBON ==========================================

    public function kasbon(){
        if (!empty($this->session->userdata('tgl1'))) {
            $dt_a   = $this->session->userdata('tgl1');
            $dt_b   = $this->session->userdata('tgl2');
            $data = array(
                'title'  => "Orchard Beauty", 
                'anak'   => $this->M_salon->ambil_anak(),
                'kasbon' => $this->M_salon->dt_kasbon(" where tanggal BETWEEN '$dt_a' AND '$dt_b' "),
            );
        }else{
            $dt   = date('Y-m-d');
            $data = array(
                'title'  => "Orchard Beauty", 
                'anak'   => $this->M_salon->ambil_anak(),
                'kasbon' => $this->M_salon->dt_kasbon(" where tgl_input = '$dt' "),
            );
        }
        
        $this->load->view('kasbon/tabel', $data);
    }

    public function kasbon2(){
        $dt_a = $this->input->post('tgl1');
        $dt_b = $this->input->post('tgl2');
        $sesi = array(
            'tgl1' => $this->input->post('tgl1'), 
            'tgl2' => $this->input->post('tgl2'), 
        );
        $this->session->set_userdata($sesi);
        $data = array(
            'title'  => "Orchard Beauty", 
            'anak'   => $this->M_salon->ambil_anak(),
            'kasbon' => $this->M_salon->dt_kasbon(" where tanggal BETWEEN '$dt_a' AND '$dt_b' "),
        );
        $this->load->view('kasbon/tabel', $data);
    }

    function input_kasbon(){
        $data_input = array(
            'tanggal'   => $this->input->post('tanggal'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_kasbon' => strtoupper($this->input->post('nm_kasbon')),
            'nominal'   => $this->input->post('nominal'),
            'admin'     => $this->session->userdata('nm_user'),
            'tgl_input' => date('Y-m-d')
        );
        $res  = $this->M_salon->InputData('ctt_kasbon', $data_input);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Input !! <div class="ml-5 btn btn-sm"><i class="fas fa-cloud-download-alt fa-2x"></i></div></div>');
        redirect("Match/kasbon");
    }

    public function edit_kasbon($id_kasbon){
        $a = $this->M_salon->dt_kasbon(" where id_kasbon ='$id_kasbon' ");
        $data = array(
            "id_kasbon"   => $a[0]->id_kasbon,
            "id_kry_2"   => $a[0]->id_kry_2,
            "nm_kasbon"   => $a[0]->nm_kasbon,
            "tanggal"     => $a[0]->tanggal,
            "nominal"    => $a[0]->nominal,
            'title'      => "Edit kasbon", 
            'anak'       => $this->M_salon->ambil_anak()
        );
        $this->load->view('kasbon/form_edit', $data);
    }

    function update_kasbon(){
        $id_kasbon  = $this->input->post('id_kasbon');
        $data_input = array(
            'tanggal'   => $this->input->post('tanggal'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_kasbon'  => strtoupper($this->input->post('nm_kasbon')),
            'nominal'   => $this->input->post('nominal')
        );
        $where = array('id_kasbon' => $id_kasbon);
        $res  = $this->M_salon->UpdateData('ctt_kasbon', $data_input, $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Update !!  <div class="ml-5 btn btn-sm"><i class="fas fa-sync-alt fa-2x"></i></div></div>');
        redirect("Match/kasbon");
    }

    function drop_kasbon($id_kasbon){
        $where = array('id_kasbon' => $id_kasbon);
        $res = $this->M_salon->DropData('ctt_kasbon', $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Hapus !!  <div class="ml-5 btn btn-sm"><i class="fas fa-times-circle fa-2x"></i></div></div>');
        redirect("Match/kasbon");
    }

    function detail_kasbon(){
        $tgl1 = $this->input->post('tgl1');
        $tgl2 = $this->input->post('tgl2');
        $data['kasbon'] = $this->M_salon->detail_kasbon($tgl1, $tgl2);

        $this->load->view('kasbon/detail_export', $data);
    }

    function summary_kasbon(){
        $tgl1 = $this->input->post('tgl3');
        $tgl2 = $this->input->post('tgl4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'kasbon'    => $this->M_salon->summary_kasbon($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('kasbon/summary_export', $data);
    }

    function excel_kasbon_sum(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'kasbon'    => $this->M_salon->summary_kasbon($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('kasbon/excel_sum', $data);
    }

    function excel_kasbon_det(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'kasbon'    => $this->M_salon->dt_kasbon(" where tanggal BETWEEN '$tgl1' AND '$tgl2' "),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('kasbon/excel_det', $data);
    }

// =============================== KASBON ==========================================

// ================================== TIPS ==========================================

    public function tips(){
        if (!empty($this->session->userdata('tgl1'))) {
            $dt_a   = $this->session->userdata('tgl1');
            $dt_b   = $this->session->userdata('tgl2');
            $data = array(
                'title'  => "Orchard Beauty", 
                'anak'   => $this->M_salon->ambil_anak(),
                'tips'   => $this->M_salon->dt_tips(" where tanggal BETWEEN '$dt_a' AND '$dt_b' "),
            );
        }else{
            $dt   = date('Y-m-d');
            $data = array(
                'title'  => "Orchard Beauty", 
                'anak'   => $this->M_salon->ambil_anak(),
                'tips'   => $this->M_salon->dt_tips(" where tgl_input = '$dt' "),
            );
        }

        $this->load->view('tips/tabel', $data);
    }

    public function tips2(){
        $dt_a = $this->input->post('tgl1');
        $dt_b = $this->input->post('tgl2');
        $sesi = array(
            'tgl1' => $this->input->post('tgl1'), 
            'tgl2' => $this->input->post('tgl2'), 
        );
        $this->session->set_userdata($sesi);
        $data = array(
            'title'  => "Orchard Beauty", 
            'anak'   => $this->M_salon->ambil_anak(),
            'tips'   => $this->M_salon->dt_tips(" where tanggal BETWEEN '$dt_a' AND '$dt_b' "),
        );
        $this->load->view('tips/tabel', $data);
    }

    function input_tips(){
        $data_input = array(
            'tanggal'   => $this->input->post('tanggal'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_tips'  => strtoupper($this->input->post('nm_tips')),
            'nominal'   => $this->input->post('nominal'),
            'admin'     => $this->session->userdata('nm_user'),
            'tgl_input' => date('Y-m-d')
        );
        $res  = $this->M_salon->InputData('ctt_tips', $data_input);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Input !! <div class="ml-5 btn btn-sm"><i class="fas fa-cloud-download-alt fa-2x"></i></div></div>');
        redirect("Match/tips");
    }

    public function edit_tips($id_tips){
        $a = $this->M_salon->dt_tips(" where id_tips ='$id_tips' ");
        $data = array(
            "id_tips"   => $a[0]->id_tips,
            "id_kry_2"   => $a[0]->id_kry_2,
            "nm_tips"   => $a[0]->nm_tips,
            "tanggal"     => $a[0]->tanggal,
            "nominal"    => $a[0]->nominal,
            'title'      => "Edit tips", 
            'anak'       => $this->M_salon->ambil_anak()
        );
        $this->load->view('tips/form_edit', $data);
    }

    function update_tips(){
        $id_tips  = $this->input->post('id_tips');
        $data_input = array(
            'tanggal'   => $this->input->post('tanggal'),
            'id_kry_2'  => $this->input->post('id_kry_2'),
            'nm_tips'  => strtoupper($this->input->post('nm_tips')),
            'nominal'   => $this->input->post('nominal')
        );
        $where = array('id_tips' => $id_tips);
        $res  = $this->M_salon->UpdateData('ctt_tips', $data_input, $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Update !!  <div class="ml-5 btn btn-sm"><i class="fas fa-sync-alt fa-2x"></i></div></div>');
        redirect("Match/tips");
    }

    function drop_tips($id_tips){
        $where = array('id_tips' => $id_tips);
        $res = $this->M_salon->DropData('ctt_tips', $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Hapus !!  <div class="ml-5 btn btn-sm"><i class="fas fa-times-circle fa-2x"></i></div></div>');
        redirect("Match/tips");
    }

    function summary_tips(){
        $tgl1 = $this->input->post('tgl3');
        $tgl2 = $this->input->post('tgl4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'tips'      => $this->M_salon->summary_tips($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('tips/summary_export', $data);
    }

    function excel_tips_sum(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'tips'      => $this->M_salon->summary_tips($tgl1, $tgl2),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('tips/excel_sum', $data);
    }

    function excel_tips_det(){
        $tgl1 = $this->uri->segment('3');
        $tgl2 = $this->uri->segment('4');
        $data = array(
            'tgl1'      => $tgl1,
            'tgl2'      => $tgl2,
            'tips'      => $this->M_salon->dt_tips(" where tanggal BETWEEN '$tgl1' AND '$tgl2' "),
            'sort'      => date('d M, y', strtotime($tgl1))." ~ ".date('d M, y', strtotime($tgl2))
        );

        $this->load->view('tips/excel_det', $data);
    }


// =============================== TIPS ==========================================

// ================================== DATA KARYAWAN ==========================================
    public function dt_anak(){
        $data = array(
            'title' => "Karyawan Laki", 
            'laki'  => $this->M_salon->dt_kry(), 
        );
        $this->load->view('anak_laki/tabel', $data);
    }

    function input_kry(){
        $data_input = array(
            'nm_kry'    => strtoupper($this->input->post('nm_kry'))
        );
        $res  = $this->M_salon->InputData('tb_karyawan', $data_input);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Input !! <div class="ml-5 btn btn-sm"><i class="fas fa-cloud-download-alt fa-2x"></i></div></div>');
        redirect("Match/dt_anak");
    }

    function update_kry(){
        $id_kry  = $this->input->post('id_kry');
        $data_input = array(
            'nm_kry'    => strtoupper($this->input->post('nm_kry'))
        );
        $where = array('id_kry' => $id_kry);
        $res  = $this->M_salon->UpdateData('tb_karyawan', $data_input, $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Update !!  <div class="ml-5 btn btn-sm"><i class="fas fa-sync-alt fa-2x"></i></div></div>');
        redirect("Match/dt_anak");
    }

    function drop_kry($id_kry){
        $where = array('id_kry' => $id_kry);
        $res = $this->M_salon->DropData('tb_karyawan', $where);
        $this->session->set_flashdata('message', '<div style="background-color: #FFA07A;" class="alert" role="alert">Data Berhasil Di Hapus !!  <div class="ml-5 btn btn-sm"><i class="fas fa-times-circle fa-2x"></i></div></div>');
        redirect('Match/dt_anak');
    }
// ================================== END DATA KARYAWAN ==========================================

// ================================================  HAK AKSES ===========================================
    function input_role(){
        $data = array(
            'nm_role'     => $this->input->post('nm_role')
        );

        $res = $this->M_salon->InputData('tb_role', $data);     
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Role Berhasil Di Tambah </div>');
        redirect('Match/dt_user');
    }

    function hak_edit($id_role){
        $a = $this->M_salon->dt_role(" where id_role ='$id_role'");
        $data = array(
            "edit_hapus"  => $a[0]->edit_hapus
        );
            // var_dump($data['edit_hapus']); exit;
        if ($data['edit_hapus'] == '1') {
            $sql = "UPDATE `tb_role` SET `edit_hapus` = '0' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }else{
            $sql = "UPDATE `tb_role` SET `edit_hapus` = '1' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Hak Akses Berhasil di Update !!</div>');
        redirect("Match/dt_user");
    }

    function hak_input($id_role){
        $a = $this->M_salon->dt_role(" where id_role ='$id_role'");
        $data = array(
            "input"  => $a[0]->input
        );
            // var_dump($data['input']); exit;
        if ($data['input'] == '1') {
            $sql = "UPDATE `tb_role` SET `input` = '0' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }else{
            $sql = "UPDATE `tb_role` SET `input` = '1' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Hak Akses Berhasil di Update !!</div>');
        redirect("Match/dt_user");
    }

    function hak_edit2($id_role){
        $a = $this->M_salon->dt_role(" where id_role ='$id_role'");
        $data = array(
            "i_grade"  => $a[0]->i_grade
        );
            // var_dump($data['i_grade']); exit;
        if ($data['i_grade'] == '1') {
            $sql = "UPDATE `tb_role` SET `i_grade` = '0' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }else{
            $sql = "UPDATE `tb_role` SET `i_grade` = '1' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Hak Akses Berhasil di Update !!</div>');
        redirect("Match/dt_user");
    }

    function hak_input2($id_role){
        $a = $this->M_salon->dt_role(" where id_role ='$id_role'");
        $data = array(
            "e_grade"  => $a[0]->e_grade
        );
            // var_dump($data['e_grade']); exit;
        if ($data['e_grade'] == '1') {
            $sql = "UPDATE `tb_role` SET `e_grade` = '0' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }else{
            $sql = "UPDATE `tb_role` SET `e_grade` = '1' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Hak Akses Berhasil di Update !!</div>');
        redirect("Match/dt_user");
    }

    function hak_gudang($id_role){
        $a = $this->M_salon->dt_role(" where id_role ='$id_role'");
        $data = array(
            "gudang"  => $a[0]->gudang
        );
            // var_dump($data['gudang']); exit;
        if ($data['gudang'] == '1') {
            $sql = "UPDATE `tb_role` SET `gudang` = '0' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }else{
            $sql = "UPDATE `tb_role` SET `gudang` = '1' WHERE `tb_role`.`id_role` = '$id_role'";
            $res = $this->db->query($sql);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Hak Akses Berhasil di Update !!</div>');
        redirect("Match/dt_user");
    }
    // ================================================ END HAK AKSES ===========================================

// ================================================ USER ==================================================================

    public function dt_user(){
        $data = array(
            'title' => "Data User", 
            'user'  => $this->M_salon->dt_user(" order by kd_user DESC"),
            'hak'   => $this->M_salon->dt_role()
        );
        $this->load->view('user/tb_user', $data);
    }

    function input_user(){
        $nm_user  = $_POST['nm_user'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $id_role  = $_POST['id_role'];
        $aktif    = $_POST['aktif'];

        $data_input = array(
            'nm_user'     => $nm_user,
            'username'    => $username,
            'password'    => $password,
            'id_role'     => $id_role,
            'aktif'       => $aktif,
            'tgl_masuk'   => date('Y-m-d')
        );
        // var_dump($data_input); exit;
        $res = $this->M_salon->InputData('tb_user', $data_input);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Pengguna Baru Berhasil Di Tambah</div>');
        redirect ('Match/dt_user');
    }

    function edit_user($kd_user){
        $a = $this->M_salon->dt_user("where kd_user ='$kd_user'");
        $data = array(
            "kd_user"   => $a[0]->kd_user,
            "nm_user"   => $a[0]->nm_user,
            "username"  => $a[0]->username,
            "password"  => $a[0]->password,
            "tgl_masuk" => $a[0]->tgl_masuk,
            "id_role"   => $a[0]->id_role,
            "nm_role"   => $a[0]->nm_role,
            "aktif"     => $a[0]->aktif,
            'title'     => "Edit User", 
            'role'      => $this->M_salon->dt_role()
        );

        $this->load->view('tema/Header', $data);
        $this->load->view('user/edit_user', $data);
        $this->load->view('tema/Footer');
    }

    function update_user(){
        $kd_user = $this->input->post('kd_user');
        $data_update = array(
            'nm_user'   => $this->input->post('nm_user'),
            'username'  => $this->input->post('username'),
            'password'  => $this->input->post('password'),
            'tgl_masuk' => $this->input->post('tgl_masuk'),
            'id_role'   => $this->input->post('id_role'),
            'aktif'     => $this->input->post('aktif'),
            'email'     => $this->input->post('email')
        );

        $where = array('kd_user' => $kd_user);
        $res = $this->M_salon->UpdateData('tb_user', $data_update, $where);     
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">User Berhasil Di Update </div>');
        redirect('Match/dt_user');
    }

    function drop_user($kd_user){
        $where = array('kd_user' => $kd_user);
        $res = $this->M_salon->DropData('tb_user', $where);
        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Pengguna Berhasil Di Hapus !!</div>');
        redirect('Match/dt_user');
    }

// ================================================ END USER ==================================================================

// ================================================ EXTRA ==================================================================
    public function cari_anak(){
        $nm_kry = $_GET['nm_kry'];
        $cari =$this->M_salon->cari_anak($nm_kry)->result();
        echo json_encode($cari);
    }
// ================================================ END EXTRA ==================================================================
// $pernyataan = "jafar resign mau ikut cpns"
// if ("lulus") {
//         echo"resin"
// }else{
//     echo "pemikiran cina ?";
// }

}