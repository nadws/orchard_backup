<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_salon extends CI_model {

	public function dt_app($where=""){
		return $this->db->query("Select * FROM tb_appoiment " .$where. " order by id_app DESC ")->result();
	}

	public function rkp_app($where=""){
		return $this->db->query("Select * FROM rekap_app " .$where. " order by nm_app ASC ")->result();
	}

	public function dt_denda($where=""){
		return $this->db->query("Select * FROM ctt_denda " .$where. " order by id_denda DESC ")->result();
	}

	public function dt_kasbon($where=""){
		return $this->db->query("Select * FROM ctt_kasbon " .$where. " order by id_kasbon DESC ")->result();
	}

	public function dt_tips($where=""){
		return $this->db->query("Select * FROM ctt_tips " .$where. " order by id_tips DESC ")->result();
	}

	public function dt_kry($where=""){
		return $this->db->query("Select * FROM tb_karyawan " .$where. " order by id_kry DESC ")->result();
	}

	public function dt_user($where=""){
		return $this->db->query("Select * FROM view_user " .$where)->result();
	}

	public function dt_role($where=""){
		return $this->db->query("Select * FROM tb_role " .$where)->result();
	}
	
	// =============================================== PROSEDUR ================================================
	public function summary_app($tgl1, $tgl2){
		return $this->db->query('call sum_app("'.$tgl1.'", "'.$tgl2.'" )')->result();
	}

	public function summary_tips($tgl1, $tgl2){
		return $this->db->query('call sum_tips("'.$tgl1.'", "'.$tgl2.'" )')->result();
	}

	public function summary_kasbon($tgl1, $tgl2){
		return $this->db->query('call sum_kasbon("'.$tgl1.'", "'.$tgl2.'" )')->result();
	}

	public function summary_denda($tgl1, $tgl2){
		return $this->db->query('call sum_denda("'.$tgl1.'", "'.$tgl2.'" )')->result();
	}
	// =============================================== SEARCHING ================================================

	function ambil_anak(){ 
		return $this->db->get('tb_karyawan');
	}

	function cari_anak($id){
		$query= $this->db->get_where('tb_karyawan',array('nm_kry'=>$id));
		return $query;
	}

	// =============================================== CRUD ================================================

	public function InputData($tabelName, $data)
	{
		$res = $this->db->insert($tabelName, $data);
		return $res;
	}

	public function UpdateData($tabelName, $data, $where){
		$res = $this->db->update($tabelName, $data, $where);
		return $res;
	}

	public function DropData($tabelName, $where){
		$res = $this->db->delete($tabelName, $where);
		return $res;
	}

}