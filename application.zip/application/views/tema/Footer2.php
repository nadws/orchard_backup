  <script src="<?= base_url('asset/'); ?>plugins/jquery/jquery.min.js"></script>
  <script src="<?= base_url('asset/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('asset/'); ?>dist/js/adminlte.min.js"></script>

</body>
</html>