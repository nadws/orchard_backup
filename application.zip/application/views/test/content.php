<section class="content">
    <div class="container-fluid">
        <h1>Test</h1>
    </div>
</section>    